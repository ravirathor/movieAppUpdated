import { AdminService } from "./admin.service";
import{HttpClientTestingModule,
       HttpTestingController} from '@angular/common/http/testing';
import { environment } from "src/environments/environment";
import { BASE_URL,
         JSON_SERVER_URLS, 
         TMDB_URLS } from "src/app/shared/config";
import { async, TestBed } from "@angular/core/testing";
import { of } from "rxjs";
import { Services } from "@angular/core/src/view";

describe('AdminService',()=>{
    let service:AdminService;
    let httpTestingController:HttpTestingController;
    const API_KEY=environment.API_KEY;
    const SEARCH_URL=BASE_URL.TMDB_API + TMDB_URLS.SEARCH_URL;
    const THEATERS_URL = environment.JSONSERVER + JSON_SERVER_URLS.THEATER_URL;   

beforeEach(()=>{
    TestBed.configureTestingModule({
providers:[AdminService],
imports:[HttpClientTestingModule]
        })
        service=TestBed.get(AdminService);
        httpTestingController=TestBed.get(HttpTestingController);
})
//afterAll(()=>{
//service.ngOnDestroy();
//})
it('on search movie',async()=>{
     const mockMovies=[{name:'Wander',id:1},{name:'WonderLust',id:2}];
     const term='Wand';
     spyOn(service,'searchMovie').and.returnValue(of(mockMovies));
     let response;
     service.searchMovie(term).subscribe(result=>response=result);
     expect(response).toEqual(mockMovies);

})
it('should search movie',async()=>{
let movies=[]
const mockMovies=[{name:'Wander',id:1},{name:'WonderLust',id:2}];
let term='Wan' 
service.searchMovie(term).subscribe(t=>{
    movies.push(t);
})
const REQ=httpTestingController.expectOne({
    method:"GET",
    url:SEARCH_URL + environment.API_KEY + '&query=' + term
})
REQ.flush(mockMovies);
expect(movies[0]).toEqual(mockMovies)
});
it('should add a new theater',async () =>{
    let data={
        tid:'1',
        name:'Plaza',
        movies:[]
    };
    let mockTheaterList={
        "theaters":[]
    };
    service.newTheater(data);
    data.movies=[];
const REQ=httpTestingController.expectOne({
    method:"GET",
    url:THEATERS_URL
});
REQ.flush(mockTheaterList);
const req=httpTestingController.expectOne({
    method:"PUT",
    url:THEATERS_URL   
});
expect(req.request.body).toBe(mockTheaterList);
req.flush(mockTheaterList)
})
it("should save now playing",()=>{
    let nowPlaying=[1,2],theaterId=1;
    let mockTheaterList={"theaters":[
        {
            "tid":"1",
            "name":"Plaza",
            "city":"Gwalior",
            "capacity":2,
            "movies":[
                8852,58588,256040,436969
            ]},
        ]};
        service.saveNowPlaying(nowPlaying,theaterId);
        const REQ=httpTestingController.expectOne({
            method:"GET",
            url:THEATERS_URL
        });
        REQ.flush(mockTheaterList);
        const req=httpTestingController.expectOne({
            method:"PUT",
            url:THEATERS_URL,
        });
        req.flush(mockTheaterList);
});
it('should throw error when save empty object',()=>{
    let nowPlaying=[], theaterId=1;
    service.saveNowPlaying(nowPlaying,theaterId);
    const REQ=httpTestingController.expectNone({
        method:"GET",
        url: THEATERS_URL
    });
 });
});