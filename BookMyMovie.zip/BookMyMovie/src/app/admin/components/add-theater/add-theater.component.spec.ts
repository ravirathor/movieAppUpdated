import { BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { HttpClientModule } from '@angular/common/http';
import { async, ComponentFixture, TestBed, fakeAsync } from '@angular/core/testing';
import { AddTheaterComponent } from './add-theater.component';
import { RouterTestingModule } from '@angular/router/testing';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FlexLayoutModule } from '@angular/flex-layout';
import { MatTabsModule, MatDialogModule, MatDialog } from '@angular/material';
import { MaterialModule } from 'src/app/material.module';
import { of } from 'rxjs';
export class MatDialogMock {
    // When the component calls this.dialog.open(...) we'll return an object
    // with an afterClosed method that allows to subscribe to the dialog result observable.
    open() {
      return {
        afterClosed: () => of({ action: true })
      };
    }
    closeAll() {
      return of();
    }
  }
  describe('AddTheaterComponent', () => {
    let component: AddTheaterComponent;
    let fixture: ComponentFixture<AddTheaterComponent>;
    let matDialog: MatDialog;
    beforeEach(async(() => {
      TestBed.configureTestingModule({
        imports: [
          RouterTestingModule,
          HttpClientModule,
          CommonModule,
          FormsModule,
          ReactiveFormsModule,
          FlexLayoutModule,
          MatTabsModule,
          MaterialModule,
          MatDialogModule,
          BrowserAnimationsModule],
        declarations: [AddTheaterComponent],
        providers: [{ provide: MatDialog, useClass: MatDialogMock }]
      }).compileComponents();
    }));
    beforeEach(() => {
      fixture = TestBed.createComponent(AddTheaterComponent);
      component = fixture.componentInstance;
      matDialog = TestBed.get(MatDialog);
      fixture.detectChanges();
    });
  
    it('should create', () => {
      expect(component).toBeTruthy();
    });

    it('should check onSubmit', () => {
      spyOn(matDialog, 'open');
      component.onSubmit();
    });
    
    it('user should update from form changes', fakeAsync(() => {
      const mockTheatre = {
        tid: 1234,
        name: 'vijji',
        city: 'banglore',
        gLocation: 'tad',
        capacity: 1234
      };
      component.newTheater.controls['tid'].setValue(mockTheatre.tid);
      component.newTheater.controls['name'].setValue(mockTheatre.name);
      component.newTheater.controls['city'].setValue(mockTheatre.city);
      component.newTheater.controls['gLocation'].setValue(mockTheatre.gLocation);
      component.newTheater.controls['capacity'].setValue(mockTheatre.capacity);
      spyOn(matDialog, 'open');
      component.onSubmit();
      expect(matDialog.open).toHaveBeenCalled();
    }));
    it('should check #dialogOk', () => {
      spyOn(matDialog, 'closeAll');
      component.dialogOk();
      expect(matDialog.closeAll).toHaveBeenCalled();
    });
  });
  