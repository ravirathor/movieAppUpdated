import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProfileComponent } from 'src/app/profile/profile.component';
import { PaymentBookingComponent } from './shared/components/payment-booking/payment-booking.component';
import { AuthGuard } from './core/auth/service/authguard.service';

const routes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  {
    path: 'home', 
    loadChildren: './home/home.module#HomeModule'  },
    // loadChildren: ()=> import ('./home/home.module').then(m=>m.HomeModule)                      
        

  { 
    path: 'movie',loadChildren:'./movie/movie.module#MovieModule'
    // loadChildren: ()=> import('./movie/movie.module').then(m=>m.MovieModule)
    //'./movie/movie.module#MovieModule'
 },
  { path: 'search',loadChildren:'./search/search.module#SearchModule'
   //loadChildren: ()=> import ('./search/search.module').then(m=>m.SearchModule)
  //'./search/search.module#SearchModule'
 },
  { path: 'profile', component: ProfileComponent, canActivate: [AuthGuard] },

  { path: 'admin',loadChildren: './admin/admin.module#AdminModule'
  //loadChildren:()=> import('./admin/admin.module').then(m=>m.AdminModule)
  // './admin/admin.module#AdminModule' 
},
  { path: 'payment/:movieTitle/:theatre/:time/:seat/:total', component: PaymentBookingComponent, canActivate: [AuthGuard] },
  { path: '**', redirectTo: '/home' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
